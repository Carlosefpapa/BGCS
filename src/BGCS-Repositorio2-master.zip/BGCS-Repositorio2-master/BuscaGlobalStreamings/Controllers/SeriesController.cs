﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BuscaGlobalStreamings.Models;

namespace BuscaGlobalStreamings.Controllers
{
    public class SeriesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SeriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Series
        public async Task<IActionResult> Detalhes()
        {
            return View();
        }

        public async Task<IActionResult> Streamings()
        {
            return View();
        }

        public async Task<IActionResult> Populares()
        {
            return View();
        }

        public async Task<IActionResult> Lista()
        {
            return View();
        }

        public async Task<IActionResult> BemAvaliadas()
        {
            return View();
        }

        public async Task<IActionResult> Resultado()
        {
            return View();
        }

    }
}
