﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BuscaGlobalStreamings.Models;

namespace BuscaGlobalStreamings.Controllers
{
    public class FilmesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FilmesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Detalhes()
        {
            return View();
        }

        public async Task<IActionResult> Streamings()
        {
            return View();
        }

        public async Task<IActionResult> Lista()
        {
            return View();
        }

        public async Task<IActionResult> Populares()
        {
            return View();
        }
        public async Task<IActionResult> Resultado()
        {
            return View();
        }
        public async Task<IActionResult> BemAvaliadas()
        {
            return View();
        }
    }
}
