﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BuscaGlobalStreamings.Models;

namespace BuscaGlobalStreamings.Controllers
{
    public class StreamingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StreamingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Lista()
        {
            return View();
        }

        public async Task<IActionResult> NetflixTV()
        {
            return View();
        }

        public async Task<IActionResult> GloboPlayTV()
        {
            return View();
        }

        public async Task<IActionResult> PrimeVideoTV()
        {
            return View();
        }

        public async Task<IActionResult> DisneyPlusTV()
        {
            return View();
        }

        public async Task<IActionResult> HBOMaxTV()
        {
            return View();
        }

        public async Task<IActionResult> ParamountPlusTV()
        {
            return View();
        }

        public async Task<IActionResult> StarPlusTV()
        {
            return View();
        }

        public async Task<IActionResult> AppleTVPlusTV()
        {
            return View();
        }

        public async Task<IActionResult> FunimationTV()
        {
            return View();
        }

        public async Task<IActionResult> Netflix()
        {
            return View();
        }

        public async Task<IActionResult> GloboPlay()
        {
            return View();
        }

        public async Task<IActionResult> PrimeVideo()
        {
            return View();
        }

        public async Task<IActionResult> DisneyPlus()
        {
            return View();
        }

        public async Task<IActionResult> HBOMax()
        {
            return View();
        }

        public async Task<IActionResult> ParamountPlus()
        {
            return View();
        }

        public async Task<IActionResult> StarPlus()
        {
            return View();
        }

        public async Task<IActionResult> AppleTVPlus()
        {
            return View();
        }

        public async Task<IActionResult> Funimation()
        {
            return View();
        }


    }
}
