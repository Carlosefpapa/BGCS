﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BuscaGlobalStreamings.Migrations
{
    public partial class M08 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "conteudoInfantil",
                table: "Accounts",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "conteudoInfantil",
                table: "Accounts");
        }
    }
}
