﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuscaGlobalStreamings.Models
{
    public class Streaming
    {
        public int Id { get; set; }
    }
}
