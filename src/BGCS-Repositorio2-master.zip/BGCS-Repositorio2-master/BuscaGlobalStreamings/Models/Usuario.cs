﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BuscaGlobalStreamings.Models
{
    [Table("Usuarios")]
    public class Usuario
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Favor informar o nome!")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Favor informar o e-mail!")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Favor informar a senha!")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [Required(ErrorMessage = "Favor informar o perfil!")]
        public Perfil Perfil { get; set; }

        [Display(Name = "Biografia")]
        [DataType(DataType.MultilineText)]
        public string Biografia { get; set; }

        public bool conteudoInfantil { get; set; }

        //public ICollection<Grupo> Grupos { get; set; }
    }

    public enum Perfil
    {
        Admin,
        User
    }
}
