const APIURL = "https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=4d4efa39693d29d922bd207ecc5fdaec&page=1";
const IMGPATH = "https://image.tmdb.org/t/p/w500";
const SEARCHAPIMOVIE = "https://api.themoviedb.org/3/search/movie?&api_key=4d4efa39693d29d922bd207ecc5fdaec&query=";
const API_LANGUAGE = '&language=pt-BR'; //DEFINE O IDIOMA DAS INFORMAÇÕES OBTIDAS NA API
//const VARSTORAGE = localStorage.getItem('flagInfantil')
//console.log(VARSTORAGE);
const CONTADULT = '&include_adult=' + localStorage.getItem('flagInfantil');
//console.log(CONTADULT);


// objeto do js para pegar os valores da url 
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());

if (params.type === 'tv') {
    window.location = `/Series/Resultado?s=${params.s}`;
}

const main = document.getElementById("main");
const form = document.getElementById("form");
const search = document.getElementById("search");

// inicialmente obter filmes da pesquisa
if (params && params.s) {
    PegarMovies(SEARCHAPIMOVIE + params.s + API_LANGUAGE + CONTADULT);
    search.value = params.s;
    //console.log(SEARCHAPIMOVIE + params.s + API_LANGUAGE + CONTADULT);
}

// puxa os dados da api 
async function PegarMovies(url) {
    const resp = await fetch(url);
    const respData = await resp.json();

    showMovies(respData.results);
}
// atualiza o html com o resultado da api 
function showMovies(movies) {
    // limpar principal
    main.innerHTML = "";

    movies.forEach((movie) => {
        const { poster_path, title, id } = movie;

        const movieEl = document.createElement("div");
        movieEl.classList.add("col");
        movieEl.classList.add("movie");
        movieEl.id = title;
        movieEl.innerHTML = `
            <div class="card shadow-sm">
                <img class="d-block w-100"
                    src="${poster_path ? IMGPATH + poster_path : "http://via.placeholder.com/1080x1580"}">
                <div class="card-body">
                    <p class="card-text">${title}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                            <a href="/Filmes/Detalhes?id=${id}" target="_self"><button type="button"
                                    class="btn btn-primary">Ver Mais</button></a>
                        </div>
                    </div>
                </div>
            </div>`
        main.appendChild(movieEl);
    });
}
//Chama uma função quando uma pesquisa for feita sem precisar atualizar a pagina 
form.addEventListener("submit", (e) => {
    e.preventDefault();

    const searchTerm = search.value;

    if (searchTerm) {
        PegarMovies(SEARCHAPIMOVIE + searchTerm + API_LANGUAGE + CONTADULT);
        //console.log(SEARCHAPIMOVIE + params.s + API_LANGUAGE + CONTADULT);
    }
});