﻿//INTEGRAÇÃO COM TMDB - CHAVE DE API

const API_KEY = 'api_key=4d4efa39693d29d922bd207ecc5fdaec'; //CHAVE API
const BASE_URL = 'https://api.themoviedb.org/3/'; //URL DE BASE PARA ENDPOINT
const BASE_URL_IMAGE = 'http://image.tmdb.org/t/p' //URL DE BASE PARA ENDPOINT - IMAGEM
const API_LANGUAGE = '&language=pt-BR'; //DEFINE O IDIOMA DAS INFORMAÇÕES OBTIDAS NA API

//CONSULTA SÉRIES POPULARES
const API_SERIE_POPULAR = BASE_URL + 'tv/' + 'on_the_air?' + API_KEY + API_LANGUAGE

fundoAleatorio(API_SERIE_POPULAR);

function fundoAleatorio(url) {
    fetch(url)
        .then(res => res.json())
        .then(data => document.getElementById("herofundo").style.backgroundImage = `linear-gradient(to right, rgba(20.20%, 18.43%, 26.67%, 0.8) 150px, rgba(30.20%, 18.43%, 26.67%, 0.8) 100%), 
                url('${BASE_URL_IMAGE}/original${data.results[Math.floor(Math.random() * data.results.length)].backdrop_path}')`);
}