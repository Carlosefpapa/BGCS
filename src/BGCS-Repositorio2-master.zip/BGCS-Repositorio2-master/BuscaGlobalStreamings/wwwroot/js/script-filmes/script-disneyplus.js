﻿//INTEGRAÇÃO COM TMDB - CHAVE DE API

const API_KEY = 'api_key=4d4efa39693d29d922bd207ecc5fdaec'; //CHAVE API
const BASE_URL = 'https://api.themoviedb.org/3/'; //URL DE BASE PARA ENDPOINT
const BASE_URL_IMAGE = 'http://image.tmdb.org/t/p/' //URL DE BASE PARA ENDPOINT - IMAGEM
const API_LANGUAGE = '&language=pt-BR'; //DEFINE O IDIOMA DAS INFORMAÇÕES OBTIDAS NA API

//CONSULTA FILMES POR SERVIÇO
const API_DISCOVER_MOVIE = BASE_URL + 'discover/movie?' + API_KEY + API_LANGUAGE + '&with_watch_providers=337&watch_region=BR'

fundoAleatorio(API_DISCOVER_MOVIE);

const main = document.getElementById('main');

const prev = document.getElementById('prev');
const current = document.getElementById('current');
const next = document.getElementById('next');

const herofundo = document.getElementById('herofundo');

var currentPage = 1;
var nextPage = 2;
var prevPage = 3;
var lastUrl = '';
var totalPages = 100;

getContent(API_DISCOVER_MOVIE);

function getContent(url) {
    lastUrl = url;
    fetch(url).then(res => res.json()).then(data => {

        if (data.results.length !== 0) {
            getFilmes(data.results);
            currentPage = data.page;
            nextPage = currentPage + 1;
            prevPage = currentPage - 1;
            totalPages = data.total_pages;

            current.innerText = currentPage + '/' + totalPages;
            if (currentPage <= 1) {
                prev.classList.add('disabled');
                next.classList.remove('disabled');
            }
            else if (currentPage >= totalPages) {
                prev.classList.remove('disabled');
                next.classList.add('disabled');
            } else {
                prev.classList.remove('disabled');
                next.classList.remove('disabled');
            }

            herofundo.scrollIntoView({ behavior: "smooth" })

        }
        else {
            main.innerHTML = `<h1>Resultados não encontrados.</h1>`
        }
    })
}

async function getFilmes(data) {

    main.innerHTML = '';

    data.forEach(filme => {
        const { poster_path, title, overview, id } = filme;

        const conteudoEl = document.createElement('div');
        conteudoEl.classList.add('filme');

        conteudoEl.innerHTML =
            `
          <div class="card">
            <img class="card-img-top" src="${poster_path ? BASE_URL_IMAGE + 'w500' + poster_path : "http://via.placeholder.com/500x750"}" alt="${title}">
            <div class="card-body">
            <h5 class="card-title">${title}</h5>
            <p class="card-text" style="text-align: justify">${overview}</p>
            <a href="/Filmes/Detalhes?id=${id}" class="btn btn-primary">Saber Mais</a>
          </div>

        `
        main.appendChild(conteudoEl);
    });

}

function fundoAleatorio(url) {
    fetch(url)
        .then(res => res.json())
        .then(data => document.getElementById("herofundo").style.backgroundImage = `linear-gradient(to right, rgba(20.20%, 18.43%, 26.67%, 0.8) 150px, rgba(30.20%, 18.43%, 26.67%, 0.8) 100%), 
                url('${BASE_URL_IMAGE}original${data.results[Math.floor(Math.random() * data.results.length)].backdrop_path}')`);
}

prev.addEventListener('click', () => {
    if (prevPage > 0) {
        pageCall(prevPage);
    }
})

next.addEventListener('click', () => {
    if (nextPage <= totalPages) {
        pageCall(nextPage);
    }
})

function pageCall(page) {
    let urlSplit = lastUrl.split('?');
    let queryParams = urlSplit[1].split('&');
    let key = queryParams[queryParams.length - 1].split('=');
    if (key[0] != 'page') {
        let url = lastUrl + '&page=' + page
        getContent(url);
    }
    else {
        key[1] = page.toString();
        let a = key.join('=');
        queryParams[queryParams.length - 1] = a;
        let b = queryParams.join('&');
        let url = urlSplit[0] + '?' + b;
        getContent(url);
    }
}