﻿//INTEGRAÇÃO COM TMDB - CHAVE DE API

const API_KEY = 'api_key=4d4efa39693d29d922bd207ecc5fdaec'; //CHAVE API
const BASE_URL = 'https://api.themoviedb.org/3/'; //URL DE BASE PARA ENDPOINT
const BASE_URL_IMAGE = 'http://image.tmdb.org/t/p' //URL DE BASE PARA ENDPOINT - IMAGEM
const API_LANGUAGE = '&language=pt-BR'; //DEFINE O IDIOMA DAS INFORMAÇÕES OBTIDAS NA API

//CONSULTA FILMES POPULARES
const API_MOVIE_POPULAR = BASE_URL + 'movie/' + 'popular?' + API_KEY + API_LANGUAGE;

//CONSULTA SÉRIES POPULARES
const API_SERIE_POPULAR = BASE_URL + 'tv/' + 'popular?' + API_KEY + API_LANGUAGE;

consultaPopulares(API_MOVIE_POPULAR);

consultaPopularesSeries(API_SERIE_POPULAR);

function consultaPopularesSeries(url) {
    fetch(url)
        .then(res => res.json())
        .then(data => document.getElementById("content-multimidia-serie").innerHTML =
            `
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[0].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[0].name}</h5>
      <p class="card-text">${data.results[0].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[0].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[1].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[1].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[1].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[1].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[2].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[2].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[2].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[2].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[3].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[3].name}</h5>
      <p class="card-text">${data.results[3].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[3].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[4].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[4].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[4].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[4].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[5].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[5].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[5].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[5].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[6].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[6].name}</h5>
      <p class="card-text">${data.results[6].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[6].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[7].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[7].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[7].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[7].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[8].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[8].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[8].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[8].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[9].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[9].name}</h5>
      <p class="card-text">${data.results[9].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[9].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[10].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[10].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[10].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[10].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[11].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[11].name}</h5>
      <p class="card-text" style="text-align: justify">${data.results[11].overview}</p>
      <a href="/Series/Detalhes?id=${data.results[11].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
            `
        );

    fundoAleatorio(url);

    function fundoAleatorio(url) {
        fetch(url)
            .then(res => res.json())
            .then(data => document.getElementById("herofundo-serie").style.backgroundImage = `linear-gradient(to right, rgba(20.20%, 18.43%, 26.67%, 0.8) 150px, rgba(30.20%, 18.43%, 26.67%, 0.8) 100%), 
                url('${BASE_URL_IMAGE}/original${data.results[Math.floor(Math.random() * data.results.length)].backdrop_path}')`);
    }

}

function consultaPopulares(url) {
    fetch(url)
        .then(res => res.json())
        .then(data => document.getElementById("content-multimidia").innerHTML =
            `
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[0].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[0].title}</h5>
      <p class="card-text">${data.results[0].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[0].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[1].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[1].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[1].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[1].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[2].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[2].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[2].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[2].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[3].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[3].title}</h5>
      <p class="card-text">${data.results[3].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[3].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[4].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[4].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[4].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[4].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[5].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[5].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[5].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[5].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[6].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[6].title}</h5>
      <p class="card-text">${data.results[6].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[6].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[7].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[7].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[7].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[7].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[8].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[8].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[8].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[8].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
</div>
<div class="card-deck" style="padding-bottom: 10px">
  <div class="card">
    <img class="card-img-top hover-overlay" src="${BASE_URL_IMAGE}/original${data.results[9].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[9].title}</h5>
      <p class="card-text">${data.results[9].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[9].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[10].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[10].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[10].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[10].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="${BASE_URL_IMAGE}/original${data.results[11].poster_path}" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">${data.results[11].title}</h5>
      <p class="card-text" style="text-align: justify">${data.results[11].overview}</p>
      <a href="/Filmes/Detalhes?id=${data.results[11].id}" class="btn btn-primary">Saber Mais</a>
    </div>
  </div
</div>
</div>
            `
        );

    fundoAleatorio(url);

    function fundoAleatorio(url) {
        fetch(url)
            .then(res => res.json())
            .then(data => document.getElementById("herofundo").style.backgroundImage = `linear-gradient(to right, rgba(20.20%, 18.43%, 26.67%, 0.8) 150px, rgba(30.20%, 18.43%, 26.67%, 0.8) 100%), 
                url('${BASE_URL_IMAGE}/original${data.results[Math.floor(Math.random() * data.results.length)].backdrop_path}')`);
    }

}