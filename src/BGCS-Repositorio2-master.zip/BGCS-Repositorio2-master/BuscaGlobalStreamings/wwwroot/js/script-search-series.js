﻿const APIURL = "https://api.themoviedb.org/3/discover/tv?sort_by=popularity.desc&api_key=4d4efa39693d29d922bd207ecc5fdaec&page=1";
const IMGPATH = "https://image.tmdb.org/t/p/w500";
const SEARCHAPISERIES = "https://api.themoviedb.org/3/search/tv?&api_key=4d4efa39693d29d922bd207ecc5fdaec&query=";
const API_LANGUAGE = '&language=pt-BR'; //DEFINE O IDIOMA DAS INFORMAÇÕES OBTIDAS NA API
const CONTADULT = '&include_adult=' + localStorage.getItem('flagInfantil');


// objeto do js para pegar os valores da url 
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());

if (params.type === 'movie') {
    window.location = `/Filmes/Resultado?s=${params.s}`;
}

const main = document.getElementById("main");
const form = document.getElementById("form");
const search = document.getElementById("search");

// inicialmente obter filmes da pesquisa
if (params && params.s) {
    PegarSeries(SEARCHAPISERIES + params.s + API_LANGUAGE + CONTADULT);
    search.value = params.s;
}

// puxa os dados da api 
async function PegarSeries(url) {
    const resp = await fetch(url);
    const respData = await resp.json();

    showMovies(respData.results);
}
// atualiza o html com o resultado da api 
function showMovies(movies) {
    // limpar principal
    main.innerHTML = "";

    movies.forEach((movie) => {
        console.log(movie);
        const { poster_path, name, id } = movie;

        const movieEl = document.createElement("div");
        movieEl.classList.add("col");
        movieEl.classList.add("movie");
        movieEl.id = name;
        movieEl.innerHTML = `
            <div class="card shadow-sm">
                <img class="d-block w-100"
                    src="${poster_path ? IMGPATH + poster_path : "http://via.placeholder.com/1080x1580"}">
                <div class="card-body">
                    <p class="card-text">${name}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                            <a href="/Series/Detalhes?id=${id}" target="_self"><button type="button"
                                    class="btn btn-primary">Ver Mais</button></a>
                        </div>
                    </div>
                </div>
            </div>`
        main.appendChild(movieEl);
    });
}

//Chama uma função quando uma pesquisa for feita sem precisar atualizar a pagina 
form.addEventListener("submit", (e) => {
    e.preventDefault();

    const searchTerm = search.value;

    if (searchTerm){
        PegarSeries(SEARCHAPISERIES + searchTerm + API_LANGUAGE + CONTADULT);
    }
});